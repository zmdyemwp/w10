
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "BoldNumTable.h"

const static int space_width = 6;

/*
		For the bold numbers with normal size, set the value of parameter "size": 0
		For the bold numbers with bigger size, set the value of parameter "size": 1
*/


int GDI_GetBoldNumWidth(char * str, int size) {
	int result = 0;
	size_t i = 0;
	for(i = 0; i < strlen(str); i++) {
		if(' ' == str[i]) {
			result += space_width;
			continue;
		}
		if('0' > str[i] || ':' < str[i]) {
			continue;
		}
		int index = str[i] - '0';
		
		if(0 > size) size = 0;
		if(2 < size) size = 2;
		result += bold_num_font_width_table[11 * size + index];
	}
	return result;
}


extern void GDI_PaintBuffer(int, int, int, int, unsigned char *, bool);
void GDI_PaintBoldNumBuffer(int x, int y, char * str, int fontSize, int alignment, bool highlight) {
	int wsum = GDI_GetBoldNumWidth(str);
	int X = 0;
	int Y = y;
	size_t i = 0;
	int height = 0;
	if(0 > alignment) {
		X = x;
	}
	else if(0 == alignment) {
		X = x - wsum/2;
	}
	else {
		X = x - wsum;
	}
	for(i = 0; i < strlen(str); i++) {
		int index = 0;
		if(' ' == str[i]) {
			X += space_width;
			continue;
		}
		else if('0' > str[i] || ':' < str[i]) {
			continue;
		}
		else {
			index = str[i] - '0';
			if(0 > fontSize) fontSize = 0;
			if(2 < fontSize) fontSize = 2;
			index += 11*fontSize;
			wsum = bold_num_font_width_table[index];
		}
		height = (int)((bold_num_font_offset_table[index+1] - bold_num_font_offset_table[index])/ceil((double)wsum/8));
		GDI_PaintBuffer(X, Y, wsum, height, (unsigned char *)bold_num_font_data_table + bold_num_font_offset_table[index], highlight);
		X += wsum;
	}
}
