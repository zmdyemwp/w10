#ifndef		__W10_BOLD_NUM_FONT_TABLE_H__
#define		__W10_BOLD_NUM_FONT_TABLE_H__

#ifdef  __cplusplus
extern  "C" {
#endif

int GDI_GetBoldNumWidth(char * str, int size = 0);
void GDI_PaintBoldNumBuffer(int x, int y, char * str, int fontSize, int alignment, bool highlight);

extern const unsigned char bold_num_font_width_table [];
extern const unsigned short bold_num_font_offset_table[];
extern const unsigned char bold_num_font_data_table[];


#ifdef  __cplusplus
}
#endif


#endif		//__W10_BOLD_NUM_FONT_TABLE_H__

